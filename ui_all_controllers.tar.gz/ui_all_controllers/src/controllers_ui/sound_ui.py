from raya.controllers.ui_controller import UIController
from raya.controllers.sound_controller import SoundController
from raya.tools.filesystem import list_files_in_folder, create_dat_folder
from raya.exceptions import *

from src.static.ui import *
from src.static.fs import *


class SoundUI():

    def __init__(self, app):
        self.app = app
        self.ui:UIController = app.ui


    async def init(self):
        self.sound:SoundController = await self.app.enable_controller('sound')

    
    async def main_display(self):
        while True:
            response = await self.ui.display_choice_selector(
                    **UI_SOUND_MAIN_DISPLAY
                )
            if response['action'] == 'back_pressed':
                return
            selection = response['selected_option']['id']
            if selection==1:
                await self.play_predefined_sound()
            # if selection==2:
            #     await self.play_custom_sound()


    async def play_predefined_sound(self):
        sound_names = self.sound.get_predefined_sounds()
        ui_data = [
                {'id':i, 'name': sound_name}
                for i, sound_name in enumerate(sound_names)
            ]
        response = await self.ui.display_choice_selector(
                **UI_SOUND_PLAY_PREDEFINED,
                data=ui_data,
            )
        if response['action'] == 'back_pressed':
            return
        sound_name = response['selected_option']['name']
        await self.sound.play_sound(name=sound_name)


    # async def play_custom_sound(self):
    #     try:
    #         files_list = list_files_in_folder(CUSTOM_SOUNDS_FOLDER)
    #     except RayaFolderDoesNotExist:
    #         create_dat_folder(CUSTOM_SOUNDS_FOLDER)
    #         files_list = []
    #     sounds_list = [file for file in files_list if file.endswith('.wav')]
    #     if not sounds_list:
    #         return

    #     print(sounds_list)
        
