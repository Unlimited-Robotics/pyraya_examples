# Sound
CUSTOM_SOUNDS_FOLDER = 'dat:custom_sounds/'